
import React from 'react';
import { Table, Button, Alert } from 'react-bootstrap';
import axios from 'axios';
class UserList extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      apiUrl: 'https://localhost:44330/api/users',
      fname:"",
      lname:"",
      city:"",
      phone:"",
      users:[],
      error: null,
    }
    this.handleSubmit = this.handleSubmit.bind(this);
    this.handleFnameChange = this.handleFnameChange.bind(this);
    this.handleLnameChange = this.handleLnameChange.bind(this);
    this.handleCityChange = this.handleCityChange.bind(this);
    this.handlePhoneChange = this.handlePhoneChange.bind(this);
  }

  /*componentDidMount() {
    const apiUrl = 'https://localhost:44330/api/users';

    fetch(apiUrl)
      .then(res => res.json())
      .then(
        (result) => {
          this.setState({
            users: result
          });
        },
        (error) => {
          this.setState({ error });
        }
      )
  }*/ 
  handleFnameChange(event){this.setState({fname: event.target.value});}
  handleLnameChange(event){this.setState({lname: event.target.value});}
  handleCityChange(event){this.setState({city: event.target.value});} 
  handlePhoneChange(event){this.setState({phone: event.target.value});}
  handleSubmit(event) {
      event.preventDefault();
    const fname=event.target.fname.value;
    const lname=event.target.lname.value;
    const city=event.target.city.value;
    const phone=event.target.phone.value;
    const userData={
      FName:fname,
      LName:lname,
      City:city,
      PhoneNumber:phone
    }
    fetch('https://localhost:44330/api/users', {

      method: 'POST',
      headers:{'content-type': 'application/json'}, 
      mode: 'cors', 
      body: JSON.stringify(userData) // body data type must match "Content-Type" header

    }).catch((e)=>{console.log(e)});
    window.location.reload(false)
    console.log(userData);
    }
    componentDidMount() {
      const apiUrl = 'https://localhost:44330/api/users';
  
      fetch(apiUrl)
        .then(res => res.json())
        .then(
          (result) => {
            this.setState({
              users: result
            });
          },
          (error) => {
            this.setState({ error });
            console.log(error)
          }
        )
    }
  render() {
    const users = this.state.users;
    users.sort((a,b)=> (a.lName > b.lName ? 1 : -1))
   /* if(error) {
      return (
        <div>Error: {error.message}</div>
      )
    } else {*/
      return(
        <div>
          
          <form onSubmit={this.handleSubmit}>
          <div>
        <label for="fname">First Name</label>
        <input
          type="text"
          name="fname"
          placeholder="Enter First Name"
          onChange={this.handleFnameChange}
          value={this.state.email}
        />
        <label>Last Name</label>
        <input
          type="text"
          name="lname"
          placeholder="Enter Last Name"
          onChange={this.handleLnameChange}
          value={this.state.lname}
        />
        <br></br>
        <label>City</label>
        <input
          type="text"
          name="city"
          placeholder="Enter City"
          onChange={this.handleCityChange}
          value={this.state.city}
        />
        <label>Phone Number</label>
        <input
          type="number"
          name="phone"
          placeholder="Enter Phone Number"
          onChange={this.handlePhoneChange}
          value={this.state.phone}
        />
      </div>
      <button type="submit">
        Add User
      </button>
          </form>
          <h2>Users List</h2>
          <hr/>
          <Table style={{marginLeft:'30%'}}>
            <thead>
              <tr>
                <th>#ID</th>
                <th>First Name</th>
                <th>Last Name</th>
                <th>City</th>
                <th>Phone Number</th>
              </tr>
            </thead>
            <tbody>
              {users.map(users => (
                <tr key={users.userId}>
                  <td>{users.userId}</td>
                  <td>{users.fName}</td>
                  <td>{users.lName}</td>
                  <td>{users.city}</td>
                  <td>{users.phoneNumber}</td>
                </tr>
              ))}
            </tbody>
          </Table>
        </div>
      )
 //   }
  }
}

export default UserList;
