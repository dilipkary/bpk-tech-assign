import logo from './logo.svg';
import './App.css';
import UserList  from './component/UserList';
import Cars from './component/Cars';

function App() {
  return (
    <div className="App">
      <h1>users</h1>
      <UserList/>
    </div>
  );
}

export default App;
